<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;


class Menu extends Model
{
    use HasFactory;
    public $timestamps = true;

    protected $fillable = [
        'name',
        'parent_id',
        'icon',
        'url',
        'route_id',
    ];

    public $appends = [
        'href', 'full-name'
    ];

    public function getHrefAttribute()
    {
        $route = $this->route()->first();
        if ($route) {
            return route($route->route);
        }
        if ($this->url) {
            return url($this->url);
        }
        return "#";
    }

    public function getFullNameAttribute()
    {
        $name = $this->name;
        return $this->parent ? 'Root / ' . $this->parent->name . ' / ' . $name : 'Root / ' . $name;
    }

    public function route()
    {
        return $this->belongsTo(Route::class);
    }

    public function children()
    {
        return $this->hasMany(Menu::class, 'parent_id', 'id');
    }

    public function parent()
    {
        return $this->belongsTo(Menu::class, 'parent_id');
    }
}
