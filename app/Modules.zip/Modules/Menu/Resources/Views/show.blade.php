<x-app-layout pageTitle="Detalles del menú" :breadcrumb="['Home' => route('dashboard'), 'Listado de menú' => route('menus.index')]">

    <x-slot name="actions">
        <a href="{{ route('menus.index') }}" class="btn btn-sm fw-bold btn-info hover-elevate-down">
            <i class="fa fa-arrow-left"></i> Volver al listado
        </a>
    </x-slot>

    <div class="card mb-5 mb-xl-10" id="kt_profile_details_view">
        <div class="card-header cursor-pointer">
            <div class="card-title m-0">
                <h3 class="fw-bold m-0">Menú</h3>
            </div>
            <a href="{{ route('menus.edit', ['menu' => $item->id]) }}" class="btn btn-primary align-self-center">Editar</a>

        </div>
        <div class="card-body p-9">
            <div class="row mb-7">              
                <x-data-line label="Nombre" :value="$item->name" first="true" />
                <x-data-line label="Icono" :value="$item->icon" />
                <x-data-line label="Link" :value="$item->href" />
                <x-data-line label="Menú padre" :value="$item->parent?$item->parent->name:'Root'" />
                <x-data-line-state label="Estado" :value="$item->state" />
                <x-data-line label="Fecha de creación" :value="$item->created_at" />
                @isset($item->creator)
                <x-data-line label="Usuario de creación" :value="$item->creator->full_name" />
                @endisset
            </div>
        </div>

    </div>
</x-app-layout>