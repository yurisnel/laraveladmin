<x-app-layout pageTitle="Gestionar menú" :breadcrumb="['Home' => route('dashboard')]">

    <x-slot name="actions">
        <a href="{{ route('menus.create') }}" class="btn btn-sm fw-bold btn-primary hover-scale btn-index">
            <span class="fa fa-plus"></span> Agregar menú</a>
    </x-slot>

    <x-data-table title="Listado de menú" :columns="['ID', 'Nombre', 'Icono', 'Estado', 'Opciones']">
    </x-data-table>

    <x-slot name="scripts">
        <script>
            "use strict";

            $(document).ready(function() {
                App.createDataTable("#table0", {
                    columns: [{
                            data: 'id'
                        }, {
                            data: 'full-name'
                        }, {
                            data: 'icon',
                        },
                        App.getColumnState(),
                        App.getColumnOptions(rootUrl + "menus/"), 
                    ],                  
                    ajaxUrl: '{{ route("menus.dataTable") }}'
                });
            })
        </script>
    </x-slot>
</x-app-layout>